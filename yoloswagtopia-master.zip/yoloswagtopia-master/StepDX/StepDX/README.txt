CSE 471 Project 3 README

Bullet Bill projectiles - Luke
Mario Sprite - Hannah and Aaron
Textured Platforms - Luke, Aaron, Hannah, Alec
Sound effects (Dieing, Jumping, Finish Line) - Aaron
Vertical Moving platforms - Aaron and Hannah
Horizontal Moving Platforms - Luke
Scoring - Aaron and Hannah