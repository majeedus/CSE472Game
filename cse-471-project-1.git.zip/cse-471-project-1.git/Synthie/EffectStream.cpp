#include "stdafx.h"
#include "EffectStream.h"


CEffectStream::CEffectStream()
{
}


CEffectStream::~CEffectStream()
{
}
